# Optional core source snapshot

For the complete project, scripts and evidence use the reviewed public repository after publication. Gemma weights and runtimes are separate. Local app: uvicorn server_v6:app --host 127.0.0.1 --port 8772. MIT code; separate Google Gemma terms.
